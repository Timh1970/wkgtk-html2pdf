# wkgtkprinter++ 
## Debian Installer

The easiest way to install wkgtkprinter++ on Debian based systems is to use the .deb package

Download the package from here, navigate to the folder where you downloades it and install it with 

```
dpkg -i wkgtk-html2pdf-X.X.X-X.deb
```

To uninstll
```
dpkg -r wkgtk-html2pdf
```

This is an alpha release; The command line interface is currently a work in progress, as are the templates.
