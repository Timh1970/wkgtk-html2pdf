## Pre-generated Files

This folder includes `demo-form.html` and `demo-form.pdf` as reference outputs.
These are regenerated when you compile and run `demo-form.cpp`.

For the format of the form to appear as expected ./demoform should be run from the folder containing `demo-form.css` and `example-logo.png`.

NOTE: The HTML will not render correctly until wkgtkprinter has been installed as it requires access to the templates.